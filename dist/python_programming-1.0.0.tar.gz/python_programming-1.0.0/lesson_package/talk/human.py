def sing():
    return 'sing'

def cry():
    return 'cry'
